create view mod as
  SELECT modulo.mod_id,
    modulo.mod_nome,
    modulo.mod_trilha,
    modulo.mod_nec,
    modulo.mod_comp
   FROM modulo
  WHERE (modulo.mod_trilha = 2);

